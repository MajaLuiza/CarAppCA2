# -*- coding: utf-8 -*-
"""
Created on Sat Sep 29 13:30:47 2018

@author: admin
"""

from car import Car, PetrolCar, DieselCar, ElectricCar, HybridCar 

class CarRentalFleet(object):     
    def __init__(self):
        self.__petrol_cars = []
        self.__electric_cars = []
        self.__diesel_cars = []
        self.__hybrid_cars = []
        # max cars available for rent from each type
        self.fullfleet_petrol = 20
        self.fullfleet_electric = 4
        self.fullfleet_diesel = 8
        self.fullfleet_hybrid = 8
        for i in range(self.fullfleet_petrol):
            self.__petrol_cars.append(PetrolCar())
        for i in range(self.fullfleet_electric):
            self.__electric_cars.append(ElectricCar())
        for i in range(self.fullfleet_diesel):
            self.__diesel_cars.append(DieselCar())
        for i in range(self.fullfleet_hybrid):
            self.__hybrid_cars.append(HybridCar())
        
             
    def getPetrolCars(self):
        return self.__petrol_cars
        
    def getElectricCars(self):
        return self.__electric_cars
    
    def getDieselCars(self):
         return self.__diesel_cars
     
    def getHybridCars(self):
         return self.__hybrid_cars
    
    
    
    def rent(self, carType):
         #check stock limit
        if carType.upper() == 'P':         
            if (len(self.getPetrolCars()) > 0):
                self.__petrol_cars.pop()
                return True
        elif carType.upper() == 'E':
            if (len(self.getElectricCars()) > 0):
                self.__electric_cars.pop()
                return True
        elif carType.upper() == 'D':
            if (len(self.getDieselCars()) > 0):
                self.__diesel_cars.pop()
                return True
        elif carType.upper() == 'H':
            if (len(self.getHybridCars()) > 0):
                self.__hybrid_cars.pop()
                return True
        return False
             
    def returnCar(self, carType):
        #check stok before return 
        if carType.upper() == 'P':
            if (len(self.getPetrolCars()) < self.fullfleet_petrol):
                self.__petrol_cars.append(PetrolCar())
                return True
        elif carType.upper() == 'E':
            if (len(self.getElectricCars()) < self.fullfleet_electric):
                self.__electric_cars.append(ElectricCar())
                return True
        elif carType.upper() == 'D':
            if (len(self.getDieselCars()) < self.fullfleet_diesel):
                self.__diesel_cars.append(DieselCar())
                return True
        elif carType.upper() == 'H':
            if (len(self.getHybridCars()) < self.fullfleet_hybrid):
                self.__hybrid_cars.append(HybridCar())
                return True
        return False
      
        
    # check fiunction for cars available to rent
    def checkCarsInStock(self):
        print('Petrol cars available: ' + str(len(self.getPetrolCars())))
        if len(self.getPetrolCars())== 0:
            print('Sorry no Petrol cars available at the monent')
        elif len(self.getPetrolCars()) >=21:
            print('Please select the option from the menu' )

        print('Electric cars available: '+ str(len(self.getElectricCars())))
        if len(self.getElectricCars())==0:
            print('Sorry no Electric cars available at the moment.')
        elif len(self.getElectricCars())>=5:
            print('Please select the option from the menu')

        print('Diesel cars available: '+ str(len(self.getDieselCars())))
        if len(self.getDieselCars())==0:
            print('Sorry no Diesel cars available at the moment.')
        elif len(self.getDieselCars())>=9:
            print('Please select the option from the menu!')
      
        print('Hybrid cars available: '+ str(len(self.getHybridCars())))
        if len(self.getHybridCars())==0:
            print('Sorry no Hybrid cars available at the moment.')
        elif len(self.getHybridCars())>=9:
            print('Please select the option from the menu')
        
        if (len(self.getDieselCars())==0 and len(self.getElectricCars())==0 and len(self.getHybridCars())==0 and len(self.getPetrolCars())==0):
            print('Sorry no cars available at the monentr.Please come back later.')
            
            
        

    def mainMenu(self):
        print(35*'#')
        print('Welcome to Aungier Car Rental')
        print(35*'#')
        keepAsking = True
        while keepAsking:
            try:
                rentedCar = None
                print( "Would you like to: \n - rent a car - R \n - return a car - U\n - for quit - Q? \n ")
                answer =  input('Please select the option from menu:   ')
                if answer.upper() == "R":
                    print('Please see below list of available cars: ')
                    self.checkCarsInStock()
                    carType = input('Please select the type of car: \nP for Petrol \nE for Electric \nD for Diesel \nH for Hybrid \n ')
                    rentedCar = self.rent(carType)
                 
                    if rentedCar == True:
                        print('\n Your order is process now and ready for collection. Thank you for using our service')
                    else:
                        print('\n Incorrect Input, please select an available car type.')
                        self.checkCarsInStock()
                
                    exitYesNo = input('Would you like to exit? Press Y if you want exit: ')
                    if exitYesNo.upper() == "Y":
                        print ('Thank You for using our service. See you soon.')
                        break
                 
                elif answer.upper() == "U":
                    carType = input('Please select what car you want to return: \nP for Petrol \nE for Electric \nD for Diesel \nH for Hybrid \n ')
                    print(' ' )
                    if carType.upper() == "P" or carType.upper() == "E" or carType.upper() == "D" or carType.upper() == "H":
                        if (self.returnCar(carType)):
                            print('\n Car returned succesfully. Thank you for using our service. Hope see you soon')
                        else:
                            print('\n Error to return the car')
                    
                        print('Please see the list of cars below:')
                        self.checkCarsInStock()
                    else:
                        print('\n Invalid Input, please select following: \nP for Petrol \nElectric \nD for Diesel \nH Hybrid')
                     
                    exitYesNo = input('Would you like to exit? Press Y if you want exit: ')
                    if exitYesNo.upper() == "Y":
                        print ('Thank You for using our service. See you soon.')
                        break
                 
                elif answer.upper() == "Q":
                    print('Thank You for using our service. See you soon.')
                    break
                    
                else:
                    print('Please try again. Please select the option from menu\n ' )
                    print(' ')
    
            except( ValueError, TypeError):
                print('Please try again. Please select the option from menu\n ')
                    
                    
if __name__=='__main__':
    aungierCar = CarRentalFleet()
    aungierCar.mainMenu()

                     






