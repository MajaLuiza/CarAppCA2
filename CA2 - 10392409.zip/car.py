# -*- coding: utf-8 -*-
"""
Created on Sat Sep 29 13:31:56 2018

@author: admin
"""

class Car(object):
    
    def __init__(self):
        self.__colour = ''
        self.__make = ''
        self.__model = ''
        self.__mileage = 0
        self.__engineSize = ''   
        self.__numberFuelCells = ''
        
    def setColour(self, colour):
        self.__colour = colour
        
    def getColour(self):
        return self.__colour
    
    def setMake(self, make):
        self.__make = make
        
    def getMake(self):
        return self.__make
    
    def setModel(self, model):
        self.__model = model
        
    def getModel(self):
        return self.__model
        
    def setMileage(self, mileage):
        self.__mileage = mileage
        
    def getMileage(self):
        return self.__mileage
    
    def setNumberFuelCells(self, numberFuelCells):
        self.__nymberFuelCells = numberFuelCells
        
    def getNumberFuelCells(self):
        return self.__numberFuelCells
    
    def setEngineSize(self, engineSize):
        self.__engineSize = engineSize
        
    def getEngineSize(self):
        return self.__engineSize
    
    
    
    def move(self, distance):
        print('Moved ' + str(distance) + 'kms')
        self.__mileage = self.__mileage + distance          
        
    def paint(self, colour):
        print('Getting a paint job - new colour is: ' + colour)
        self.__colour =  colour
        
class ElectricCar(Car):
    def __init__(self):
        Car.__init__(self)
        self.__numberFuelCells = 1
        
    def getNumberFuelCells(self):
        return self.__numberFuelCells
    
    def setNumberFuelCells(self, numberFuelCells):
        self.__numberFuelCells = numberFuelCells
        
class PetrolCar(Car):
     def __init__(self):
        Car.__init__(self)
        self.__engineSize = ''
        
     def getEngineSize(self):
        return self.__engineSize
    
     def setEngineSize(self, engineSize):
        self.__engineSize = engineSize
        
class DieselCar(Car):
     def __init__(self):
        Car.__init__(self)
        self.__engineSize = ''
        
     def getEngineSize(self):
        return self.__engineSize
    
     def setEngineSize(self, engineSize):
        self.__numberFuelCells = engineSize
        
class HybridCar(Car):
    def __init__(self):
        Car.__init__(self)
        self.__numberFuelCells = 1
        
    def getNumberFuelCells(self):
        return self.__numberFuelCells
    
    def setNumberFuelCells(self, numberFuelCells):
        self.__numberFuelCells = numberFuelCells
        
    
    
